import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const GoalInput = (props) => {
  const [enteredGoal, setEnteredGoal] = useState('');

  const goalInputHandler = (enteredText) => {
    setEnteredGoal(enteredText);
  };

  return (
    <View style={styles.inputContainer1}>

      <Text style={styles.tekst1}>PROGRAMIRANJE 3 </Text>
      <br />

<Text style={styles.tekst2}> Odsjek za informacijske znanosti </Text>
      <br />

<Text style={styles.tekst3}>ECTS: 3 </Text>
      <br />

      <Text>
        Cilj je kolegija upoznati studente s osnovama izrada distribuiranih
        aplikacija. Na predavanjima se obraduju osnovni teorijski koncepti
        racunarstva u oblaku, infrastrukturi kao usluzi, programskoj podrsci kao
        usluzi dok se na vjezbama na prakticnim primjerima, koristenjem java
        programskog jezika izraduje aplikacija za mobilne uredaje bazirane na
        Android platformi uz distribuiranu pohranu podataka na mreznoj
        aplikaciji.
        
      </Text>
      
      <br />

      <View style={styles.inputContainer0}>
        <TextInput
          placeholder="Ishodi kolegija"
          style={styles.input}
          onChangeText={goalInputHandler}
          value={enteredGoal}
        />
        <Button
          style={styles.gumb}
          title="DODAJ"
          onPress={props.onAddGoal.bind(this, enteredGoal)}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  inputContainer0: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  inputContainer1: {
    textAlign: 'justify',
    alignItems: 'center',
  },


  input: {
    width: '65%',
    borderColor: 'blue',
    borderWidth: 1,
    padding: 15,
    fontFamily: 'Verdana',
  },


  tekst1: {
    color: 'orange',
    fontSize: 24,
    textAlign: 'auto',
  },

  tekst2: {
    color: 'blue',
    fontSize: 15,
    textAlign: 'auto',
  },

  tekst3: {
    color: 'blue',
    fontSize: 15,
    textAlign: 'auto',
  },


  
});

export default GoalInput;
